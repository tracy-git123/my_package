#my_package
This library was created as an example of how to publish your own python package

'python setup.py sdist'

'pip install git+https://github.com/James-Leslie/example-python.git'

'pip install --upgrade git+https://github.com/James-Leslie/example-python.git'

...